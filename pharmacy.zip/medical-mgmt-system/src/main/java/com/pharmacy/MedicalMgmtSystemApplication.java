package com.pharmacy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalMgmtSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalMgmtSystemApplication.class, args);
	}

}
